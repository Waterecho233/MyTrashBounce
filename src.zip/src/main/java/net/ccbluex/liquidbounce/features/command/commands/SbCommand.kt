/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Listenable
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.util.ResourceLocation

class SbCommand : Command("cat"), Listenable {
    private var toggle = false
    private var image = 0
    private var running = 0f
    private val nachoTextures = arrayOf(
        ResourceLocation("liquidbounce/nacho/1.png"),
        ResourceLocation("liquidbounce/nacho/2.png"),
        ResourceLocation("liquidbounce/nacho/3.png"),
        ResourceLocation("liquidbounce/nacho/4.png"),
        ResourceLocation("liquidbounce/nacho/5.png"),
        ResourceLocation("liquidbounce/nacho/6.png"),
        ResourceLocation("liquidbounce/nacho/7.png"),
        ResourceLocation("liquidbounce/nacho/8.png"),
        ResourceLocation("liquidbounce/nacho/9.png"),
        ResourceLocation("liquidbounce/nacho/10.png"),
        ResourceLocation("liquidbounce/nacho/11.png"),
        ResourceLocation("liquidbounce/nacho/12.png"),
		ResourceLocation("liquidbounce/nacho/13.png"),
		ResourceLocation("liquidbounce/nacho/14.png"),
		ResourceLocation("liquidbounce/nacho/15.png"),
		ResourceLocation("liquidbounce/nacho/16.png"),
		ResourceLocation("liquidbounce/nacho/17.png"),
		ResourceLocation("liquidbounce/nacho/18.png"),
		ResourceLocation("liquidbounce/nacho/19.png"),
		ResourceLocation("liquidbounce/nacho/20.png"),
		ResourceLocation("liquidbounce/nacho/21.png"),
		ResourceLocation("liquidbounce/nacho/22.png"),
		ResourceLocation("liquidbounce/nacho/23.png"),
		ResourceLocation("liquidbounce/nacho/24.png"),
		ResourceLocation("liquidbounce/nacho/25.png"),
		ResourceLocation("liquidbounce/nacho/26.png"),
		ResourceLocation("liquidbounce/nacho/27.png"),
		ResourceLocation("liquidbounce/nacho/28.png"),
		ResourceLocation("liquidbounce/nacho/29.png"),
		ResourceLocation("liquidbounce/nacho/30.png"),
		ResourceLocation("liquidbounce/nacho/31.png"),
		ResourceLocation("liquidbounce/nacho/32.png"),
		ResourceLocation("liquidbounce/nacho/33.png"),
		ResourceLocation("liquidbounce/nacho/34.png"),
		ResourceLocation("liquidbounce/nacho/35.png"),
		ResourceLocation("liquidbounce/nacho/36.png")
    )

    init {
        LiquidBounce.eventManager.registerListener(this)
    }

    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        toggle = !toggle
        ClientUtils.displayChatMessage(if (toggle) "§aCAT!! :)" else "§cWhy cancel! :(")
    }

    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        if (!toggle)
            return

        running += 0.15f * RenderUtils.deltaTime
        val scaledResolution = ScaledResolution(mc)
        RenderUtils.drawImage(nachoTextures[image], scaledResolution.scaledWidth - 300, scaledResolution.scaledHeight - 130, 256, 128)
        if (scaledResolution.scaledWidth <= running)
            running = -64f
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (!toggle) {
            image = 0
            return
        }

        image++
        if (image >= nachoTextures.size) image = 0
    }

    override fun handleEvents() = true

    override fun tabComplete(args: Array<String>): List<String> {
        return listOf("CAT")
    }
}