/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.utils.render.shader.shaders;

import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.shader.Shader;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.minecraft.client.gui.*;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL20;
import org.lwjgl.input.Mouse;

import java.awt.*;

public final class BackgroundShader extends Shader {

    public final static BackgroundShader BACKGROUND_SHADER = new BackgroundShader();

    private float time;
	public static int mouseX;
	public static int mouseY;

    public BackgroundShader() {
        super("background.frag");
    }
	
	@EventTarget
	public void onRender2D(final Render2DEvent e) {
		this.mouseX = Mouse.getX();
		this.mouseY = Mouse.getY();
	}

    @Override
    public void setupUniforms() {
        setupUniform("iResolution");
        setupUniform("iTime");
		setupUniform("iMouse");
    }

    @Override
    public void updateUniforms() {
		mouseX = Mouse.getX();
		mouseY = Mouse.getX();
        final int resolutionID = getUniform("iResolution");
        if(resolutionID > -1)
            GL20.glUniform2f(resolutionID, (float) Display.getWidth(), (float) Display.getHeight());
		
		final ScaledResolution scaledResolution = new ScaledResolution(mc);
		final int width = scaledResolution.getScaledWidth();
        final int height = scaledResolution.getScaledHeight();
		
        final int timeID = getUniform("iTime");
        if(timeID > -1) GL20.glUniform1f(timeID, time);

        time += 0.003F * RenderUtils.deltaTime;
		
		final int mouseID = getUniform("iMouse");
		if(mouseID > -1)
            GL20.glUniform2i(mouseID, mouseX  * width / mc.displayWidth ,height - mouseY * height / mc.displayHeight - 1 );//LOL, I NEVER DO THE SHADER, BECAUSE SHADER IS MAKE ME SAD :( 
		mouseX += Mouse.getX();
		mouseY += Mouse.getX();
    }

}
